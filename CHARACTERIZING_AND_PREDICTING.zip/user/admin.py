from django.contrib import admin
from user.models import Users
from user.models import Purchase
from user.models import Feedback

class AdminUsers(admin.ModelAdmin):
	list_display = ['username','profession', 'email','mobile','location']


class AdminPurchase(admin.ModelAdmin):
	list_display = ['customer', 'purhased','quantity','totalprice', 'status']


class AdminFeedback(admin.ModelAdmin):
	list_display = ['user', 'product','isPurchased','rating', 'review','sentiment']



admin.site.register(Users,AdminUsers)
admin.site.register(Purchase,AdminPurchase)
admin.site.register(Feedback,AdminFeedback)





