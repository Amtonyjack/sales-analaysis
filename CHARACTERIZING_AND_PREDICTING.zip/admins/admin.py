
from django.contrib import admin
from admins.models import Prodcuts

class AdminProdcuts(admin.ModelAdmin):
	list_display = ['product_name', 'version_name','vendor_name','vendor_name', 'price','featuers','images']



admin.site.register(Prodcuts,AdminProdcuts)

