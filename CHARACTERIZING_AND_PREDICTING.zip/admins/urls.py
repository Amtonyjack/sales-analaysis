from django.conf.urls import url

from admins import views

# app_name = 'products'

urlpattern = [
    url(r'^home/$',views.home,name='home'),
    url(r'^$',views.index,name='index'),
    url(r'^upload/products/$',views.uploadproducts,name='uploadproducts'),
    url(r'^charts/Multivendor-Analysis/(?P<chart_type>\w+)/$',views.charts,name='charts'),
    url(r'^charts/Knowledge-Based-Opinion/(?P<chart_type>\w+)/$',views.charts1,name='charts1'),
    url(r'^charts/Region-wise-Opinion-Analysis/(?P<chart_type>\w+)/$',views.charts2,name='charts2'),
    url(r'^charts/Sentiment-Wise-Analysis/(?P<chart_type>\w+)/$',views.charts3,name='charts3'),
    url(r'^user_details/$',views.user_details,name='user_details'),
    url(r'^view_reviews/$',views.view_reviews,name='view_reviews'),
    url(r'^deleteobj/(?P<pk>\d+)/$',views.deleteobj,name = 'deleteobj'),
    url(r'^logout/$',views.logout,name='logout'),
]